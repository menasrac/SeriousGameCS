
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ConveyorBelt : MonoBehaviour
{
    public player player;
    public GameObject selectedPanel;
    public float itemSpeed = 5f; // Vitesse des objets sur le tapis roulant
    public float conveyorSpeed = 0.5f;
    Vector3 spawnPoint = new Vector3(-8f, 0f, 0f);
    private static Transform selectedItem = null; // Variable pour stocker l'objet s�lectionn�
    float _lastSpawnTime = 0.0f;
    private int duration;
    private Items items;


    public AudioClip selectedItemSound;


    //private static ConveyorBelt instance;
    private void Awake()
    {
        //instance = this;
    }
    void Start()
    {
        items = new Items();
    }
    //Temps entre chaque apparition d'item
    public static float deltaTime;
    void Update()
    {
        //Faire apparaitre les items toutes les deltaTime sec
        if (Time.time > _lastSpawnTime + deltaTime)
        {

            Item item = chooseRandomItem(player.level);
            //On check qu'il n'y pas de pbs de texture
            if (item.sprite == null)
            {
                item = new Item("plasticBottle", 10f, Item.ItemType.Plastic);
            }
            AddItem(item);
            _lastSpawnTime = Time.time;
        }

        // Faire bouger les objets sur le tapis roulant
        for (int i = 0; i < transform.childCount; i++)
        {
            Transform item = transform.GetChild(i);
            item.position += new Vector3(itemSpeed * Time.deltaTime, 0f, 0f);
        }

        //Vector3 rightEdge = transform.position + transform.right * transform.localScale.x * 0.5f;

        // Si l'objet entre dans la zone de s�lection, on le met en s�lectionn�
        if (transform.childCount > 0 && selectedItem == null && transform.GetChild(0).localPosition.x > 0.1f)
        {
            //Transform item = transform.GetChild(0);
            //ItemScript itemScript = item.GetComponent<ItemScript>(); // Ajoutez cette ligne
            //itemScript.SelectItem(); // Ajoutez cette ligne
            selectedItem = transform.GetChild(0); // Stocker l'objet s�lectionn�
            selectedItem.GetComponent<ItemScript>().SelectItem(); // Activer la s�lection de l'objet
            EffectsManager.PlaySelectedItemSound(selectedItemSound);
        }
        // Si l'objet est sorti de la zone du tapis roulant, le supprimer
        if (transform.childCount > 0 && transform.GetChild(0).localPosition.x + transform.GetChild(0).localScale.x * 0.5f > transform.right.x * 0.5f)
        {
            AllBins.letInGarbage(transform.GetChild(0).GetComponent<ItemScript>().item);
            Destroy(transform.GetChild(0).gameObject);
            Destroy(selectedItem.gameObject);
            selectedItem = null;
        }

        //Animer le tapis
        GetComponent<Renderer>().material.mainTextureOffset = new Vector2(-itemSpeed/15*Time.time, 0f);

    }

    public Item chooseRandomItem(int Gamestate)
    {
        List<Item> allItems = items.GetItems(Gamestate);

        int randomIndex = Random.Range(0, allItems.Count);

        // Obtient un �l�ment al�atoire � partir de la liste des items
        Item randomItem = allItems[randomIndex].randomizeTexture();
        return (randomItem);
    }

    public void AddItem(Item item)
    {
        GameObject newItem = new GameObject();
        ItemScript representation = newItem.AddComponent<ItemScript>();
        newItem.AddComponent<SpriteRenderer>();
        newItem.name = item.name;
        //newItem.transform.parent = transform;
        representation.Init(item);

        // Ajouter le nouvel objet � la liste des enfants du tapis roulant
        newItem.transform.SetParent(transform);

        // Positionner le nouvel objet sur le tapis roulant
        Vector3 spawnPosition = new Vector3(-0.5f, 0, -1);
        newItem.transform.localPosition = spawnPosition;
        newItem.transform.localScale = new Vector3(0.002563929f*0.66f, 0.01785761f*0.66f, 0.2f);
        
    }

    public static Transform getSelectedItem()
    {
        return (selectedItem);
    }

  public void clearItems()
    {
        deltaTime = 2.4f;
        foreach (Transform child in transform)
        {
            GameObject.Destroy(child.gameObject);
        }
    }



}

