using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ConveyorBelt : MonoBehaviour
{
    public player player;
    public GameObject selectedPanel;
    public float itemSpeed = 5f; // Vitesse des objets sur le tapis roulant
    Vector3 spawnPoint = new Vector3(-8f, 0f, 0f);
    private Transform selectedItem = null; // Variable pour stocker l'objet s�lectionn�
    float _lastSpawnTime = 0.0f;
    private int duration;
    private Items items;
    void Start()
    {
        items = new Items();
    }


    void Update()
    {
        duration = 3;
        if (Time.time > _lastSpawnTime + duration)
        {

            Item item = chooseRandomItem(1);
            //On check qu'il n'y pas de pbs de texture
            if (item.sprite == null)
            {
                item = new Item("plasticBottle", 10f, Item.ItemType.Plastic);
            }
            AddItem(item);
            _lastSpawnTime = Time.time;
        }

        // Faire bouger les objets sur le tapis roulant
        for (int i = 0; i < transform.childCount; i++)
        {
            Transform item = transform.GetChild(i);
            item.position += new Vector3(itemSpeed * Time.deltaTime, 0f, 0f);
        }

        //Vector3 rightEdge = transform.position + transform.right * transform.localScale.x * 0.5f;

        // Si l'objet entre dans la zone de s�lection, on le met en s�lectionn�
        if (transform.childCount > 0 && transform.GetChild(0).localPosition.x > 0.3f)
        {
            Transform item = transform.GetChild(0);
            ItemScript itemScript = item.GetComponent<ItemScript>(); // Ajoutez cette ligne
            itemScript.SelectItem(); // Ajoutez cette ligne
            selectedItem = transform.GetChild(0); // Stocker l'objet s�lectionn�
            selectedItem.GetComponent<ItemScript>().SelectItem(); // Activer la s�lection de l'objet
        }
        // Si l'objet est sorti de la zone du tapis roulant, le supprimer
        if (transform.childCount > 0 && transform.GetChild(0).localPosition.x + transform.GetChild(0).localScale.x * 0.5f > transform.right.x * 0.5f)
        {
            if (transform.GetChild(0).GetComponent<ItemScript>().item.type != Item.ItemType.Organic)
            {
                player.AddPoints(-transform.GetChild(0).GetComponent<ItemScript>().item.score);
            }
            Destroy(transform.GetChild(0).gameObject);
            Destroy(selectedItem.gameObject);
        }
    }

    public Item chooseRandomItem(int Gamestate)
    {
        List<Item> allItems = items.GetItems();
        //Charger l'image depuis les ressources
        //Texture2D texture = Resources.Load<Texture2D>("Sprites/Plastic/plasticBottle");

        //if (texture == null)
        //{
        //    Debug.LogError("texture existe po");
        //}
        //Sprite sprite = Sprite.Create(texture, new Rect(0.0f, 0.0f, texture.width, texture.height), new Vector2(0.5f, 0.5f), 25.0f);
        int i = Random.Range(0, 2);
        Item item;
        if (i == 0)
        {
            item = new Item("plasticBottle", 10.0f, Item.ItemType.Plastic);
        }
        else
        {
            item = new Item("apple", 20.0f, Item.ItemType.Organic);
        }
        int randomIndex = Random.Range(0, allItems.Count);

        // Obtient un �l�ment al�atoire � partir de la liste des items
        Item randomItem = allItems[randomIndex];


        return (randomItem);
    }

    public void AddItem(Item item)
    {
        GameObject newItem = new GameObject();
        ItemScript representation = newItem.AddComponent<ItemScript>();
        newItem.AddComponent<SpriteRenderer>();
        newItem.name = item.name;
        //newItem.transform.parent = transform;
        representation.Init(item);

        // Ajouter le nouvel objet � la liste des enfants du tapis roulant
        newItem.transform.SetParent(transform);

        // Positionner le nouvel objet sur le tapis roulant
        Vector3 spawnPosition = new Vector3(-0.5f, 0, -1);
        newItem.transform.localPosition = spawnPosition;
        newItem.transform.localScale = new Vector3(0.002563929f*0.66f, 0.01785761f*0.66f, 0.2f);
        
        Debug.Log(transform.localScale);

    }

    public Transform getSelectedItem()
    {
        return (selectedItem);
    }

}

